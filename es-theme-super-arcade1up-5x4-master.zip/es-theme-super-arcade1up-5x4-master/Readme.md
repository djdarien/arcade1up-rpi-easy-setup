theme name:     Super Arcade1Up 5x4 Theme 

designed by:    Travis Wilson ( Super Retropie and Retro Gaming )

facebook:		www.facebook.com/groups/superretropie

twitter:		www.twitter.com/superretropie

email:			superretropieretrogaming@gmail.com

version         1.6.1

<------------------------------------------------------------------------------------------>

License

This theme is being actively developed, a great deal of work has been put into the theme and art so please DO NOT use the graphics I have created in other projects.

You are free to modify the theme for your PERSONAL USE ONLY - please do not share modified versions of this theme.

Commercial distribution is prohibited

<------------------------------------------------------------------------------------------>

Travis Wilson / Super Retropie and Retro Gaming / made this theme. 

This theme is not for use with any kind of loaded images. 

This theme is not for use with anything Supreme Retro Gaming related.

<------------------------------------------------------------------------------------------>

Supported Systems and Custom Collections

2player

3do

3ds

4player

aae

acclaim

adamsfamily

advision

ags

amiga

amigacd32

amstrad

android

apple2

arcade

asteroids

astrocade

atari800

atari2600

atari5200

atari7800

atarijaguar

atarilynx

atarist

atomiswave

auto-allgames

auto-favorites

auto-lastplayed

batman

battletoads

bbcmicro

bomberman

btmups

bubblebobble

c64

capcom

castlevania

cdimono1

centipede

channelf

chromium

coleco

colecovision

contra

cps1

cps2

cps3

crashbandicoot

crvision

custom-collections

daphne

dataeast

defender

digdug

disney

donkeykong

doom

doubledragon

dreamcast

earthwormjim

electron

famicom

famicom-hacks

fatalfury

fba

fbn

fds

finalfantasy

frogger

galaga

gameandwatch

gamegear

gamegear-hacks

gb

gb-hacks

gb-super

gba

gba-hacks

gbc

gbc-hacks

gc

genesis

genesis-hacks

ghoulsnghosts

hacks

hulk

ibm

indianajones

intellivision

irem

jamesbond

joust

kaneko

kirby

kodi

kof

konami

lego

mame

mame-advmame

mame-libretro

mame-mame4all

mario

mariokart

marioparty

markiii

markiii-hacks

marvel

mastersystem

mega32x

megacd

megadrive

megadrive-hacks

megadrive-japan

megaman

megamanx

mess

metalslug

metroid

midway

mortalkombat

msdos

msx

msx2

n64

namco

naomi

nbajam

nds

neogeo

neogeo-cd

nes

nes-hacks

ngp

ngpc

ninjagaiden

odyssey

openbor

oric

outrun

pacman

panasonic

pc

pc88

pc98

pce-cd

pcengine

pcfx

pico8

pokemini

pokemon

pokemon-hacks

ports

powerrangers

princeofpersia

ps2

psikyo

psp

pspminis

psx

puzzle

racing

residualvm

retropie

roadrash

robocop

samuraishodown

satellaview

saturn

sc-3000

scummvm

sega

sega32x

segacd

segamarkiii

sfc

sfc-cd

sfc-hacks

sg-1000

sgb

shinobi

shmups

simpsons

snes

snes-cd

snes-hacks

snk

sonic

sony

spaceinvaders

spiderman

splatterhouse

startrek

starwars

steam

stratagus

streetfighter

supergrafx

supervision

taito

tecmo

tetris

tg-cd

tg16

ti99

tiger

tmnt

trs-80

vector

vectrex

vhs

vic20

videopac

virtualboy

visco

vmnuon

wario

wii

wiiu

wiiware

wonderswan

wonderswancolor

wwf

x1

x68000

xmen

zelda

zmachine

zx81

zxspectrum

** there is a launching image folder with a launching.png inside to match the theme


